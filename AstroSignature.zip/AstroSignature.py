#
# ***********************************************
#
# AstroSignature.py — Custom Text Signature Tool for Siril
# Author: Randy Holder
# Contact: randy.holder7@gmail.com
# Version: 1.4.0
#
# Copyright (C) 2026 Randy Holder
# SPDX-License-Identifier: GPL-3.0-or-later
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
#
# ***********************************************
#
# Description:
# Adds a two-line italic text signature to the currently loaded Siril image.
# Line 1: Your name + target name (editable each time)
# Line 2: Session details (editable each time)
# Features: 9-position grid selector, font dropdown, independent font size
# sliders for each line, opacity control, adjustable edge margin, and
# vertical flip correction.
#
# VERTICAL FLIP CORRECTION CHECKBOX:
# Check ON  — for images that have been plate-solved in Siril (Siril flips
#             the image during plate solving). Also applies to smart scopes
#             such as Dwarf 3, Seestar, Vespera whose raw data is natively
#             vertically flipped. This is the correct setting for most users.
# Check OFF — for images whose pixel data is correctly oriented and has NOT
#             been flipped by Siril. If unsure, try ON first.
#
# IMPORTANT: The signature is permanently written into the image pixel data.
# Always save the signed image as a NEW file after applying to preserve
# your unsigned master image.
#
# Tested with Siril 1.4.2 on Windows. Requires sirilpy >= 0.6.37.
# Should work on any telescope/camera combination supported by Siril.
#
# Version History:
# 1.0.0 - Initial release — two-line text signature, flip correction
# 1.1.0 - Added 9-position grid selector (dropdown)
# 1.2.0 - Added font selection dropdown from available Windows fonts
# 1.3.0 - Added independent font size sliders for Line 1 and Line 2
#          QA verified across all 9 positions and both flip states
# 1.3.1 - Cross-platform font support — Windows, macOS, Linux
# 1.3.2 - Preserve source bit depth/range for FITS, 16-bit TIFF, and 8-bit JPEG/TIFF
# 1.3.3 - Fix 8-bit JPEG write-back by sending normalized float pixel data to Siril
# 1.3.4 - Fix blank output for TIFF inputs; smart image pipeline handles
#          HW/CHW/HWC layouts and 8-bit/16-bit/float ranges automatically
#          Enhancement credit: Don Heffernan (Issue #7)
# 1.3.5 - GUI version label corrected; default fields restored to author defaults
# 1.3.6 - Generic default field values for friendlier first-run experience
#          (pipe-separated placeholders guide new users on formatting)
# 1.3.7 - Dialog window made resizable (minsize 620x680) to prevent clipping
#          on high-DPI displays or systems with large UI fonts (Issue #7)
# 1.3.8 - Settings persistence: last-used values saved to astrosignature.json
#          and restored on next launch; profile-ready JSON structure for
#          future named profiles (Issue #2)
# 1.3.9 - Named signature profiles (Issue #4). New dropdown lets users save,
#          switch between, and delete named presets (e.g. "Newsletter" with
#          a larger font and different position). A non-deletable "Default"
#          profile is always available. Selecting a profile loads its values
#          for editing/preview only; Apply still only updates last_used and
#          never modifies a profile. Deleting the last custom profile clears
#          the fields for fresh input. Reuses the profile-ready JSON
#          structure introduced in 1.3.8 -- no config file format change.
# 1.3.10 - Remember window size across sessions (Issue #9). The dialog's
#          width/height are saved to last_used on Apply, Cancel, or window
#          close, and restored on next launch. Independent of profile
#          selection -- window size is a UI preference, not a signature
#          field, so switching profiles never resizes the window. A
#          620x730 floor and current-screen ceiling keep restored sizes
#          sane if the saved size predates a display change.
# 1.4.0  - Adjustable edge margin. New "Margin (%)" slider (1-10%, step 0.5,
#          default 2.5) replaces the hard-coded 2.5% edge inset in
#          apply_signature(). Applies to both axes: horizontal margin is a
#          percentage of image width, vertical margin a percentage of image
#          height. Saved in last_used and in named profiles like opacity;
#          settings files and profiles saved before 1.4.0 have no margin
#          key and fall back to 2.5, so existing signatures are unchanged.
#          Minimum dialog height raised 730 -> 810 so the new slider row
#          doesn't push the Apply/Cancel buttons out of view; the floor is
#          capped at screen height on small displays.
#          QA verified across all 9 positions and both flip states.
#
# ***********************************************

VERSION = "1.4.0"

import sys
import os

# ── Siril interface ───────────────────────────────────────────────────────────
try:
    import sirilpy as s
    if not s.check_module_version('>=0.6.37'):
        print("Error: requires sirilpy module >= 0.6.37 (Siril >= 1.4.0)")
        sys.exit(1)
    from sirilpy import SirilError
    s.ensure_installed("numpy", "Pillow")
except ImportError as e:
    print(f"ERROR: Could not import sirilpy: {e}")
    sys.exit(1)

import numpy as np
from PIL import Image, ImageDraw, ImageFont


# ── Settings persistence ──────────────────────────────────────────────────────
SETTINGS_FILENAME = "astrosignature.json"

DEFAULTS = {
    "name":     "Your Name  |  Target Name",
    "session":  "Your Location  |  Exposure  |  Subs  |  Filter",
    "opacity":  40,
    "margin":   2.5,    # edge inset, % of width (x) and % of height (y)
    "flipped":  True,
    "position": "Bottom Right",
    "font":     None,   # None -> resolved to Georgia Italic / OS default at runtime
    "size1":    28,
    "size2":    22,
    "width":    620,
    "height":   810,
}

# Dialog size floor. Height raised from 730 to 810 in 1.4.0 to make room for the
# Margin slider row (measured natural height 798 px; 730 clipped the buttons).
MIN_WIN_W = 620
MIN_WIN_H = 810

# Margin slider bounds (percent). Stored values are clamped/snapped to these
# on load so a hand-edited or corrupt config can't push text off the image.
MARGIN_MIN  = 1.0
MARGIN_MAX  = 10.0
MARGIN_STEP = 0.5


def _sanitize_margin(value):
    """Coerce a stored margin to a float in [MARGIN_MIN, MARGIN_MAX], snapped to
    MARGIN_STEP. Missing/invalid values fall back to the default (2.5)."""
    import math
    try:
        v = float(value)
    except (TypeError, ValueError):
        return DEFAULTS["margin"]
    if not math.isfinite(v):
        return DEFAULTS["margin"]
    v = max(MARGIN_MIN, min(MARGIN_MAX, v))
    return round(v / MARGIN_STEP) * MARGIN_STEP


def _config_path():
    """Return the config file path, preferring the script directory with a home-dir fallback."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    primary = os.path.join(script_dir, SETTINGS_FILENAME)
    try:
        test = primary + ".tmp"
        with open(test, "w") as f:
            f.write("")
        os.remove(test)
        return primary
    except OSError:
        return os.path.join(os.path.expanduser("~"), SETTINGS_FILENAME)


def load_settings():
    """Load last-used settings from JSON config. Returns merged dict with DEFAULTS as fallback."""
    import json
    path = _config_path()
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            saved = data.get("last_used", {})
            merged = dict(DEFAULTS)
            merged.update({k: v for k, v in saved.items() if k in DEFAULTS})
            merged["margin"] = _sanitize_margin(merged.get("margin"))
            print(f"Settings loaded from: {path}")
            return merged
        except Exception as e:
            print(f"WARNING: Could not read settings file ({e}) -- using defaults.")
    return dict(DEFAULTS)


def save_settings(params, font_name):
    """Persist last-used settings to JSON config. Called only on Apply."""
    import json
    path = _config_path()
    try:
        existing = {}
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    existing = json.load(f)
            except Exception:
                existing = {}

        existing["last_used"] = {
            "name":     params["name"],
            "session":  params["session"],
            "opacity":  params["opacity"],
            "margin":   params["margin"],
            "flipped":  params["flipped"],
            "position": params["position"],
            "font":     font_name,
            "size1":    params["size1"],
            "size2":    params["size2"],
        }
        if "profiles" not in existing:
            existing["profiles"] = {}

        with open(path, "w", encoding="utf-8") as f:
            json.dump(existing, f, indent=2)
        print(f"Settings saved to: {path}")
    except Exception as e:
        print(f"WARNING: Could not save settings ({e})")


def save_window_geometry(width, height):
    """Persist the dialog's current width/height only. Called on Apply, Cancel,
    and window-close so resizing is remembered regardless of how the dialog
    was dismissed. Merges into whatever last_used already exists rather than
    overwriting it, so it never clobbers signature field values, and it is
    independent of profiles -- window size is a UI preference, not part of
    any named profile."""
    import json
    path = _config_path()
    try:
        existing = {}
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    existing = json.load(f)
            except Exception:
                existing = {}

        if "last_used" not in existing:
            existing["last_used"] = {}
        existing["last_used"]["width"] = width
        existing["last_used"]["height"] = height
        if "profiles" not in existing:
            existing["profiles"] = {}

        with open(path, "w", encoding="utf-8") as f:
            json.dump(existing, f, indent=2)
    except Exception as e:
        print(f"WARNING: Could not save window size ({e})")


# ── Named profiles ────────────────────────────────────────────────────────────
# Profiles (including the non-deletable "Default") are stored under the
# "profiles" key of the same JSON config used for last_used settings. This
# key was added preemptively in 1.3.8 specifically to support this feature
# without a file-format change (Issue #4).

RESERVED_PROFILE_NAME = "Default"


def _params_to_profile_dict(params, font_name):
    """Extract the persistable fields from a params dict into a plain profile record."""
    return {
        "name":     params["name"],
        "session":  params["session"],
        "opacity":  params["opacity"],
        "margin":   params["margin"],
        "flipped":  params["flipped"],
        "position": params["position"],
        "font":     font_name,
        "size1":    params["size1"],
        "size2":    params["size2"],
    }


def _read_config():
    """Read the full config file as a dict; returns {} if missing/unreadable."""
    import json
    path = _config_path()
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"WARNING: Could not read settings file ({e}).")
    return {}


def _write_config(data):
    import json
    path = _config_path()
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return True
    except Exception as e:
        print(f"WARNING: Could not save settings ({e})")
        return False


def list_profile_names():
    """Return profile names with 'Default' always first, followed by others alphabetically."""
    data = _read_config()
    profiles = data.get("profiles", {})
    others = sorted(n for n in profiles.keys() if n != RESERVED_PROFILE_NAME)
    names = [RESERVED_PROFILE_NAME] + others
    return names


def load_profile(name):
    """Load a named profile. Returns a merged dict (DEFAULTS as fallback for missing keys),
    or None if the profile does not exist."""
    data = _read_config()
    profiles = data.get("profiles", {})
    record = profiles.get(name)
    if record is None:
        return None
    merged = dict(DEFAULTS)
    merged.update({k: v for k, v in record.items() if k in DEFAULTS})
    # Profiles saved before 1.4.0 have no "margin" key -> DEFAULTS (2.5) applies.
    merged["margin"] = _sanitize_margin(merged.get("margin"))
    return merged


def save_profile(name, params, font_name):
    """Create or overwrite a named profile with the current field values."""
    name = (name or "").strip()
    if not name:
        raise ValueError("Profile name cannot be empty.")
    data = _read_config()
    if "profiles" not in data:
        data["profiles"] = {}
    data["profiles"][name] = _params_to_profile_dict(params, font_name)
    ok = _write_config(data)
    if ok:
        print(f"Profile '{name}' saved.")
    return ok


def delete_profile(name):
    """Delete a named profile. Refuses to delete the reserved 'Default' profile."""
    if name == RESERVED_PROFILE_NAME:
        print("WARNING: The Default profile cannot be deleted.")
        return False
    data = _read_config()
    profiles = data.get("profiles", {})
    if name not in profiles:
        print(f"WARNING: Profile '{name}' not found -- nothing to delete.")
        return False
    del profiles[name]
    data["profiles"] = profiles
    ok = _write_config(data)
    if ok:
        print(f"Profile '{name}' deleted.")
    return ok


# ── GUI dialog ────────────────────────────────────────────────────────────────
def get_user_input():
    try:
        import tkinter as tk
        from tkinter import messagebox

        # ── Load last-used settings ──
        cfg = load_settings()

        root = tk.Tk()
        root.title(f"AstroSignature Tool v{VERSION}")
        root.resizable(True, True)
        root.configure(bg="#2b2b2b")

        root.update_idletasks()
        # ── Restore last-used window size (Issue #9) ──
        # Clamp to the MIN_WIN_W x MIN_WIN_H floor (matches minsize -- prevents
        # the pre-1.3.7 clipping bug from recurring) and to the current screen
        # as a ceiling (in case the saved size came from a larger display).
        # The floor itself is capped at the screen size so the dialog never
        # opens taller than a small laptop display.
        screen_w = root.winfo_screenwidth()
        screen_h = root.winfo_screenheight()
        floor_w = min(MIN_WIN_W, screen_w)
        floor_h = min(MIN_WIN_H, screen_h)
        try:
            saved_w = int(cfg.get("width", MIN_WIN_W))
            saved_h = int(cfg.get("height", MIN_WIN_H))
        except (TypeError, ValueError):
            saved_w, saved_h = MIN_WIN_W, MIN_WIN_H
        w = max(floor_w, min(saved_w, screen_w))
        h = max(floor_h, min(saved_h, screen_h))
        x = (root.winfo_screenwidth() // 2) - (w // 2)
        y = (root.winfo_screenheight() // 2) - (h // 2)
        root.geometry(f"{w}x{h}+{x}+{y}")
        root.minsize(floor_w, floor_h)

        # ── Corrected: version label matches VERSION constant ──
        tk.Label(root, text=f"AstroSignature Tool  v{VERSION}",
                bg="#1a1a2e", fg="#c9a84c",
                font=("Arial", 13, "bold"), pady=10).pack(fill="x")

        # ── Signature profiles (Issue #4) ──
        # Selecting a profile from the dropdown loads its saved values into the
        # fields below for editing/preview. It does NOT get saved anywhere until
        # the user explicitly clicks Save. Apply never touches profiles -- it
        # only updates last_used, exactly as it always has.
        tk.Label(root, text="Signature Profile:",
                bg="#2b2b2b", fg="#ffffff",
                font=("Arial", 9)).pack(anchor="w", padx=20, pady=(12, 4))

        profile_var = tk.StringVar(value="")  # blank on launch -- fields are pre-filled from last_used instead
        pframe = tk.Frame(root, bg="#2b2b2b")
        pframe.pack(fill="x", padx=20)

        # Built with a placeholder now; real command wiring happens once the
        # rest of the field variables exist further down (see refresh_profile_menu()).
        profile_dropdown = tk.OptionMenu(pframe, profile_var, "")
        profile_dropdown.config(bg="#3c3f41", fg="#ffffff", font=("Arial", 10),
                               activebackground="#4a6fa5", activeforeground="#ffffff",
                               highlightthickness=0, relief="flat", width=22)
        profile_dropdown["menu"].config(bg="#3c3f41", fg="#ffffff",
                                       activebackground="#4a6fa5", activeforeground="#ffffff",
                                       font=("Arial", 10))
        profile_dropdown.pack(side="left")

        save_profile_btn = tk.Button(pframe, text="Save",
                 bg="#4a6fa5", fg="white", font=("Arial", 9, "bold"),
                 relief="flat", padx=10, pady=3, cursor="hand2")
        save_profile_btn.pack(side="left", padx=(10, 0))

        delete_profile_btn = tk.Button(pframe, text="Delete",
                 bg="#7a3030", fg="white", font=("Arial", 9),
                 relief="flat", padx=10, pady=3, cursor="hand2",
                 state="disabled")
        delete_profile_btn.pack(side="left", padx=(6, 0))

        tk.Label(root, text="Line 1 — Your name + Target  (use  |  to separate fields):",
                bg="#2b2b2b", fg="#ffffff",
                font=("Arial", 9)).pack(anchor="w", padx=20, pady=(12, 0))

        # ── Pre-populate from saved settings (falls back to generic defaults on first run) ──
        name_var = tk.StringVar(value=cfg["name"])
        name_entry = tk.Entry(root, textvariable=name_var, width=58,
                bg="#3c3f41", fg="#ffffff",
                font=("Arial", 10),
                relief="flat", bd=4)
        name_entry.pack(padx=20, pady=(2, 0))

        tk.Label(root, text="Line 2 — Session details  (use  |  to separate fields):",
                bg="#2b2b2b", fg="#ffffff",
                font=("Arial", 9)).pack(anchor="w", padx=20, pady=(10, 0))

        session_var = tk.StringVar(value=cfg["session"])
        session_entry = tk.Entry(root, textvariable=session_var, width=58,
                                 bg="#3c3f41", fg="#ffffff",
                                 font=("Arial", 10), relief="flat", bd=4)
        session_entry.pack(padx=20, pady=(2, 0))
        session_entry.focus()
        session_entry.select_range(0, "end")

        tk.Label(root, text="Opacity (%):",
                bg="#2b2b2b", fg="#ffffff",
                font=("Arial", 9)).pack(anchor="w", padx=20, pady=(10, 0))
        opacity_var = tk.IntVar(value=cfg["opacity"])
        oframe = tk.Frame(root, bg="#2b2b2b")
        oframe.pack(fill="x", padx=20)
        tk.Scale(oframe, from_=10, to=80, orient="horizontal",
                variable=opacity_var, bg="#2b2b2b", fg="#ffffff",
                highlightthickness=0, troughcolor="#3c3f41",
                activebackground="#c9a84c", length=400).pack(side="left")
        tk.Label(oframe, textvariable=opacity_var,
                bg="#2b2b2b", fg="#c9a84c",
                font=("Arial", 10, "bold"), width=3).pack(side="left", padx=4)

        # Edge margin slider (1.4.0) -- % of width horizontally, % of height vertically
        tk.Label(root, text="Margin (%)  — distance from image edges:",
                bg="#2b2b2b", fg="#ffffff",
                font=("Arial", 9)).pack(anchor="w", padx=20, pady=(8, 0))
        margin_var = tk.DoubleVar(value=cfg["margin"])
        mframe = tk.Frame(root, bg="#2b2b2b")
        mframe.pack(fill="x", padx=20)
        tk.Scale(mframe, from_=MARGIN_MIN, to=MARGIN_MAX, resolution=MARGIN_STEP,
                orient="horizontal",
                variable=margin_var, bg="#2b2b2b", fg="#ffffff",
                highlightthickness=0, troughcolor="#3c3f41",
                activebackground="#c9a84c", length=400).pack(side="left")
        tk.Label(mframe, textvariable=margin_var,
                bg="#2b2b2b", fg="#c9a84c",
                font=("Arial", 10, "bold"), width=4, anchor="e").pack(side="left", padx=(4, 0))
        tk.Label(mframe, text="%",
                bg="#2b2b2b", fg="#c9a84c",
                font=("Arial", 10, "bold")).pack(side="left")

        # Flip checkbox
        flipped_var = tk.BooleanVar(value=cfg["flipped"])
        tk.Checkbutton(root,
                      text="Apply vertical flip correction\n"
                           "(ON for plate-solved images and smart scopes — Dwarf 3, Seestar, Vespera etc.)",
                      variable=flipped_var,
                      bg="#2b2b2b", fg="#ffffff", selectcolor="#3c3f41",
                      activebackground="#2b2b2b", activeforeground="#c9a84c",
                      font=("Arial", 9), justify="left").pack(anchor="w", padx=20, pady=(8, 0))

        # Position selector — dropdown
        tk.Label(root, text="Signature Position:",
                bg="#2b2b2b", fg="#ffffff",
                font=("Arial", 9)).pack(anchor="w", padx=20, pady=(12, 4))

        pos_var = tk.StringVar(value=cfg["position"])
        positions = [
            "Top Left", "Top Center", "Top Right",
            "Middle Left", "Center", "Middle Right",
            "Bottom Left", "Bottom Center", "Bottom Right"
        ]
        pos_dropdown = tk.OptionMenu(root, pos_var, *positions)
        pos_dropdown.config(bg="#3c3f41", fg="#ffffff", font=("Arial", 10),
                           activebackground="#4a6fa5", activeforeground="#ffffff",
                           highlightthickness=0, relief="flat", width=20)
        pos_dropdown["menu"].config(bg="#3c3f41", fg="#ffffff",
                                   activebackground="#4a6fa5", activeforeground="#ffffff",
                                   font=("Arial", 10))
        pos_dropdown.pack(anchor="w", padx=20, pady=(0, 4))

        # Font selector dropdown
        tk.Label(root, text="Font:",
                bg="#2b2b2b", fg="#ffffff",
                font=("Arial", 9)).pack(anchor="w", padx=20, pady=(10, 4))

        available_fonts = get_available_fonts()
        font_names = [f[0] for f in available_fonts]
        font_paths = {f[0]: f[1] for f in available_fonts}

        # Resolve saved font name; fall back to Georgia Italic then first available
        default_font = font_names[0]
        for name in font_names:
            if "Georgia" in name and "Bold" not in name:
                default_font = name
                break
        saved_font = cfg.get("font")
        if saved_font and saved_font in font_names:
            default_font = saved_font

        font_var = tk.StringVar(value=default_font)
        font_dropdown = tk.OptionMenu(root, font_var, *font_names)
        font_dropdown.config(bg="#3c3f41", fg="#ffffff", font=("Arial", 10),
                            activebackground="#4a6fa5", activeforeground="#ffffff",
                            highlightthickness=0, relief="flat", width=25)
        font_dropdown["menu"].config(bg="#3c3f41", fg="#ffffff",
                                    activebackground="#4a6fa5", activeforeground="#ffffff",
                                    font=("Arial", 10))
        font_dropdown.pack(anchor="w", padx=20, pady=(0, 4))

        # Font size controls — Line 1 and Line 2 independent
        tk.Label(root, text="Font Size — Line 1 (Name / Target):",
                bg="#2b2b2b", fg="#ffffff",
                font=("Arial", 9)).pack(anchor="w", padx=20, pady=(10, 0))
        size1_var = tk.IntVar(value=cfg["size1"])
        sf1 = tk.Frame(root, bg="#2b2b2b")
        sf1.pack(fill="x", padx=20)
        tk.Scale(sf1, from_=12, to=120, orient="horizontal",
                variable=size1_var, bg="#2b2b2b", fg="#ffffff",
                highlightthickness=0, troughcolor="#3c3f41",
                activebackground="#c9a84c", length=440).pack(side="left")
        tk.Label(sf1, textvariable=size1_var,
                bg="#2b2b2b", fg="#c9a84c",
                font=("Arial", 10, "bold"), width=3).pack(side="left", padx=4)

        tk.Label(root, text="Font Size — Line 2 (Session Details):",
                bg="#2b2b2b", fg="#ffffff",
                font=("Arial", 9)).pack(anchor="w", padx=20, pady=(8, 0))
        size2_var = tk.IntVar(value=cfg["size2"])
        sf2 = tk.Frame(root, bg="#2b2b2b")
        sf2.pack(fill="x", padx=20)
        tk.Scale(sf2, from_=12, to=120, orient="horizontal",
                variable=size2_var, bg="#2b2b2b", fg="#ffffff",
                highlightthickness=0, troughcolor="#3c3f41",
                activebackground="#c9a84c", length=440).pack(side="left")
        tk.Label(sf2, textvariable=size2_var,
                bg="#2b2b2b", fg="#c9a84c",
                font=("Arial", 10, "bold"), width=3).pack(side="left", padx=4)

        # ── Profile row wiring (deferred until here since it needs the field vars above) ──
        def clear_fields_for_new_input():
            """Blank text fields and reset controls to generic defaults for fresh input."""
            name_var.set("")
            session_var.set("")
            opacity_var.set(DEFAULTS["opacity"])
            margin_var.set(DEFAULTS["margin"])
            flipped_var.set(DEFAULTS["flipped"])
            pos_var.set(DEFAULTS["position"])
            size1_var.set(DEFAULTS["size1"])
            size2_var.set(DEFAULTS["size2"])
            font_var.set(default_font)

        def update_delete_button_state():
            sel = profile_var.get()
            if sel and sel != RESERVED_PROFILE_NAME:
                delete_profile_btn.config(state="normal")
            else:
                delete_profile_btn.config(state="disabled")

        def on_profile_pick(selected_name):
            prof = load_profile(selected_name)
            if prof is None:
                return
            name_var.set(prof["name"])
            session_var.set(prof["session"])
            opacity_var.set(prof["opacity"])
            margin_var.set(prof["margin"])
            flipped_var.set(prof["flipped"])
            pos_var.set(prof["position"])
            size1_var.set(prof["size1"])
            size2_var.set(prof["size2"])
            saved_font_name = prof.get("font")
            if saved_font_name and saved_font_name in font_names:
                font_var.set(saved_font_name)
            update_delete_button_state()

        def refresh_profile_menu():
            menu = profile_dropdown["menu"]
            menu.delete(0, "end")
            for pname in list_profile_names():
                menu.add_command(
                    label=pname,
                    command=lambda v=pname: (profile_var.set(v), on_profile_pick(v))
                )

        def on_save_profile():
            from tkinter import simpledialog
            current_sel = profile_var.get()
            new_name = simpledialog.askstring(
                "Save Profile", "Profile name:",
                initialvalue=current_sel, parent=root
            )
            if new_name is None:
                return
            new_name = new_name.strip()
            if not new_name:
                messagebox.showwarning("Missing", "Please enter a profile name.")
                return
            chosen_font_name = font_var.get()
            snapshot = {
                "name":     name_var.get().strip(),
                "session":  session_var.get().strip(),
                "opacity":  opacity_var.get(),
                "margin":   _sanitize_margin(margin_var.get()),
                "flipped":  flipped_var.get(),
                "position": pos_var.get(),
                "size1":    size1_var.get(),
                "size2":    size2_var.get(),
            }
            try:
                ok = save_profile(new_name, snapshot, chosen_font_name)
            except ValueError as e:
                messagebox.showwarning("Missing", str(e))
                return
            if ok:
                refresh_profile_menu()
                profile_var.set(new_name)
                update_delete_button_state()
                messagebox.showinfo("Saved", f"Profile '{new_name}' saved.")
            else:
                messagebox.showerror("Error", "Could not save profile -- check console for details.")

        def on_delete_profile():
            selected = profile_var.get()
            if not selected or selected == RESERVED_PROFILE_NAME:
                return
            if not messagebox.askyesno("Delete Profile",
                                        f"Delete profile '{selected}'? This cannot be undone."):
                return
            ok = delete_profile(selected)
            if ok:
                refresh_profile_menu()
                profile_var.set("")
                clear_fields_for_new_input()
                update_delete_button_state()
            else:
                messagebox.showerror("Error", f"Could not delete profile '{selected}'.")

        save_profile_btn.config(command=on_save_profile)
        delete_profile_btn.config(command=on_delete_profile)
        refresh_profile_menu()
        update_delete_button_state()

        result = {"ok": False}

        # Save warning
        warn_frame = tk.Frame(root, bg="#3a1a00", bd=1, relief="solid")
        warn_frame.pack(fill="x", padx=20, pady=(12, 0))
        tk.Label(warn_frame,
                text="⚠  The signature is permanently baked into the image pixels.\n"
                     "After applying, save as a NEW file — do not overwrite your master.",
                bg="#3a1a00", fg="#ffcc66",
                font=("Arial", 9, "bold"), pady=6, justify="center").pack()

        def _capture_and_save_window_size():
            """Read the dialog's current size and persist it. Safe to call from
            Apply, Cancel, or the window-close button -- never touches signature
            fields or profiles."""
            try:
                w_now = root.winfo_width()
                h_now = root.winfo_height()
                if w_now > 1 and h_now > 1:
                    save_window_geometry(w_now, h_now)
            except Exception as e:
                print(f"WARNING: Could not read window size ({e})")

        def on_apply():
            if not session_var.get().strip():
                messagebox.showwarning("Missing", "Please enter session details.")
                return
            chosen_font_name = font_var.get()
            result.update({
                "ok": True,
                "name": name_var.get().strip(),
                "session": session_var.get().strip(),
                "opacity": opacity_var.get(),
                "margin": _sanitize_margin(margin_var.get()),
                "flipped": flipped_var.get(),
                "position": pos_var.get(),
                "font_path": font_paths[chosen_font_name],
                "font_name": chosen_font_name,
                "size1": size1_var.get(),
                "size2": size2_var.get()
            })
            save_settings(result, chosen_font_name)
            # Capture size after save_settings (which rewrites last_used wholesale)
            # so the saved width/height survive.
            _capture_and_save_window_size()
            root.destroy()

        def on_cancel():
            _capture_and_save_window_size()
            root.destroy()

        # Window-close (titlebar X) should remember size too, same as Cancel.
        root.protocol("WM_DELETE_WINDOW", on_cancel)

        bframe = tk.Frame(root, bg="#2b2b2b")
        bframe.pack(pady=14)
        tk.Button(bframe, text="  Apply Signature  ", command=on_apply,
                 bg="#4a6fa5", fg="white", font=("Arial", 10, "bold"),
                 relief="flat", padx=12, pady=6,
                 cursor="hand2").pack(side="left", padx=8)
        tk.Button(bframe, text="  Cancel  ", command=on_cancel,
                 bg="#555555", fg="white", font=("Arial", 10),
                 relief="flat", padx=12, pady=6,
                 cursor="hand2").pack(side="left", padx=8)

        root.mainloop()
        return result if result["ok"] else None

    except Exception as e:
        print(f"ERROR opening dialog: {e}")
        return None


def get_font_dirs():
    """Return a list of font directories for the current OS."""
    import platform
    system = platform.system()
    if system == "Windows":
        return ["C:/Windows/Fonts/"]
    elif system == "Darwin":  # macOS
        return [
            "/Library/Fonts/",
            "/System/Library/Fonts/",
            os.path.expanduser("~/Library/Fonts/"),
        ]
    else:  # Linux
        return [
            "/usr/share/fonts/",
            "/usr/local/share/fonts/",
            os.path.expanduser("~/.fonts/"),
            os.path.expanduser("~/.local/share/fonts/"),
        ]


def get_available_fonts():
    """Scan system font directories and return available (display_name, file_path) tuples."""
    import platform
    system = platform.system()

    # Curated font candidates per OS
    if system == "Windows":
        candidates = [
            ("Georgia Italic",              "georgiai.ttf"),
            ("Georgia Bold Italic",         "georgiaz.ttf"),
            ("Times New Roman Italic",      "timesi.ttf"),
            ("Times New Roman Bold Italic", "timesbi.ttf"),
            ("Palatino Italic",             "palatinoi.ttf"),
            ("Garamond Italic",             "garamondi.ttf"),
            ("Calibri Italic",              "calibrii.ttf"),
            ("Calibri Bold Italic",         "calibriz.ttf"),
            ("Cambria Italic",              "cambriai.ttf"),
            ("Cambria Bold Italic",         "cambriaz.ttf"),
            ("Arial Italic",                "ariali.ttf"),
            ("Arial Bold Italic",           "arialbi.ttf"),
            ("Verdana Italic",              "verdanai.ttf"),
            ("Verdana Bold Italic",         "verdanaz.ttf"),
            ("Trebuchet Italic",            "trebucit.ttf"),
            ("Book Antiqua Italic",         "bkanti.ttf"),
            ("Century Gothic Italic",       "gothici.ttf"),
            ("Comic Sans MS Italic",        "comicsi.ttf"),
            ("Segoe UI Italic",             "segoeuii.ttf"),
            ("Consolas Italic",             "consolasbi.ttf"),
        ]
    elif system == "Darwin":  # macOS
        candidates = [
            ("Georgia Italic",              "Georgia Italic.ttf"),
            ("Georgia Bold Italic",         "Georgia Bold Italic.ttf"),
            ("Times New Roman Italic",      "Times New Roman Italic.ttf"),
            ("Times New Roman Bold Italic", "Times New Roman Bold Italic.ttf"),
            ("Palatino Italic",             "Palatino.ttc"),
            ("Baskerville Italic",          "Baskerville.ttc"),
            ("Didot Italic",                "Didot.ttc"),
            ("Garamond Italic",             "EBGaramond-Italic.ttf"),
            ("Helvetica Italic",            "Helvetica.ttc"),
            ("Arial Italic",                "Arial Italic.ttf"),
            ("Arial Bold Italic",           "Arial Bold Italic.ttf"),
            ("Verdana Italic",              "Verdana Italic.ttf"),
            ("Verdana Bold Italic",         "Verdana Bold Italic.ttf"),
            ("Trebuchet Italic",            "Trebuchet MS Italic.ttf"),
            ("Futura Italic",               "Futura.ttc"),
            ("Optima Italic",               "Optima.ttc"),
            ("Comic Sans MS Italic",        "Comic Sans MS Italic.ttf"),
        ]
    else:  # Linux
        candidates = [
            ("DejaVu Serif Italic",         "DejaVuSerif-Italic.ttf"),
            ("DejaVu Serif Bold Italic",    "DejaVuSerif-BoldItalic.ttf"),
            ("DejaVu Sans Italic",          "DejaVuSans-Oblique.ttf"),
            ("DejaVu Sans Bold Italic",     "DejaVuSans-BoldOblique.ttf"),
            ("Liberation Serif Italic",     "LiberationSerif-Italic.ttf"),
            ("Liberation Serif Bold Italic","LiberationSerif-BoldItalic.ttf"),
            ("Liberation Sans Italic",      "LiberationSans-Italic.ttf"),
            ("Liberation Sans Bold Italic", "LiberationSans-BoldItalic.ttf"),
            ("FreeSerif Italic",            "FreeSerif.ttf"),
            ("FreeSans Italic",             "FreeSans.ttf"),
            ("Ubuntu Italic",               "Ubuntu-RI.ttf"),
            ("Ubuntu Bold Italic",          "Ubuntu-BI.ttf"),
            ("Noto Serif Italic",           "NotoSerif-Italic.ttf"),
            ("Noto Sans Italic",            "NotoSans-Italic.ttf"),
        ]

    font_dirs = get_font_dirs()
    available = []

    for name, filename in candidates:
        for font_dir in font_dirs:
            # Search recursively for Linux which has subdirectories
            if system == "Linux":
                for root_dir, dirs, files in os.walk(font_dir):
                    if filename in files:
                        available.append((name, os.path.join(root_dir, filename)))
                        break
            else:
                path = os.path.join(font_dir, filename)
                if os.path.exists(path):
                    available.append((name, path))
                    break

    # Fallback — use Pillow's default if nothing found
    if not available:
        available.append(("Default Font", "default"))
        print("WARNING: No system fonts found — using Pillow default font.")

    return available


def find_font(size, font_path=None):
    """Load a font by path, with cross-platform fallback chain."""
    # Try the requested font first
    if font_path and font_path != "default" and os.path.exists(font_path):
        try:
            return ImageFont.truetype(font_path, size)
        except Exception:
            pass

    # Cross-platform fallback chain
    import platform
    system = platform.system()

    if system == "Windows":
        fallbacks = [
            "C:/Windows/Fonts/georgiai.ttf",
            "C:/Windows/Fonts/timesi.ttf",
            "C:/Windows/Fonts/calibrii.ttf",
            "C:/Windows/Fonts/ariali.ttf",
            "C:/Windows/Fonts/verdanai.ttf",
            "C:/Windows/Fonts/arial.ttf",
        ]
    elif system == "Darwin":
        fallbacks = [
            "/Library/Fonts/Arial Italic.ttf",
            "/Library/Fonts/Verdana Italic.ttf",
            "/System/Library/Fonts/Helvetica.ttc",
            "/Library/Fonts/Arial.ttf",
        ]
    else:  # Linux
        fallbacks = [
            "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Italic.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSerif-Italic.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Oblique.ttf",
            "/usr/share/fonts/truetype/freefont/FreeSerif.ttf",
        ]

    for path in fallbacks:
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue

    # Final fallback — Pillow default (no path needed)
    print(f"WARNING: No fonts found — using Pillow default (no size control).")
    return ImageFont.load_default()


def _data_to_hwc_rgb_float01(data):
    """Return (HWC RGB float image in 0..1, metadata needed to restore original layout/range).

    Handles all image layouts Siril may deliver:
      HW       — 2D grayscale
      CHW      — Siril native channel-first (1 or 3 channels)
      HWC      — channel-last (1, 3, or 4 channels)

    Also handles all common bit depths:
      uint8    — standard 8-bit
      uint16   — 16-bit TIFF / FITS
      float32  — normalized FITS float
      uint16 container with 8-bit values — JPEG loaded by Siril into wide array
    """
    arr = np.asarray(data)
    meta = {
        "shape": arr.shape,
        "dtype": arr.dtype,
        "layout": "unknown",
        "channels": None,
        "scale": 1.0,
        "output_scale": 1.0,
        "float_input": np.issubdtype(arr.dtype, np.floating),
        "looks_8bit": False,
    }

    # Identify Siril/Python image layout
    if arr.ndim == 2:
        meta["layout"] = "HW"
        meta["channels"] = 1
        work = arr[..., None]
    elif arr.ndim == 3 and arr.shape[0] in (1, 3):
        meta["layout"] = "CHW"
        meta["channels"] = arr.shape[0]
        work = np.transpose(arr, (1, 2, 0))
    elif arr.ndim == 3 and arr.shape[-1] in (1, 3, 4):
        meta["layout"] = "HWC"
        meta["channels"] = arr.shape[-1]
        work = arr[..., :3]
    else:
        raise ValueError(f"Unsupported image array shape from Siril: {arr.shape}")

    work = work.astype(np.float32, copy=False)

    # Determine source range.
    # Siril can load 8-bit JPEGs into a uint16 container while actual pixel
    # values remain 0..255. Inspecting the actual finite max (not just dtype)
    # lets us detect this and avoid scaling errors that produce blank output.
    # The same logic correctly identifies 16-bit TIFFs (max near 65535).
    finite = work[np.isfinite(work)]
    maxv = float(finite.max()) if finite.size else 1.0

    if np.issubdtype(arr.dtype, np.integer):
        dtype_max = float(np.iinfo(arr.dtype).max)
        if maxv <= 255.0 and dtype_max > 255.0:
            # 8-bit image (JPEG) stored in a wider Siril array
            scale = 255.0
            output_scale = dtype_max
            meta["looks_8bit"] = True
            print(f"  Image range detected: 8-bit values in {arr.dtype} container (JPEG-like)")
        else:
            # True 16-bit (TIFF/FITS) or 8-bit uint8
            scale = dtype_max
            output_scale = dtype_max
            print(f"  Image range detected: {arr.dtype} full range (scale={dtype_max:.0f})")
    else:
        # Float input (FITS float32 etc.)
        if maxv <= 1.0:
            scale = 1.0
            output_scale = 1.0
        elif maxv <= 255.0:
            scale = 255.0
            output_scale = 1.0
            meta["looks_8bit"] = True
        elif maxv <= 65535.0:
            scale = 65535.0
            output_scale = 1.0
        else:
            scale = maxv
            output_scale = 1.0
        print(f"  Image range detected: float input, max={maxv:.4f}, scale={scale:.0f}")

    meta["scale"] = scale
    meta["output_scale"] = output_scale

    work01 = np.clip(work / scale, 0.0, 1.0)

    # Pillow drawing is RGB. For mono images, make temporary RGB.
    if work01.shape[-1] == 1:
        work01 = np.repeat(work01, 3, axis=-1)
    elif work01.shape[-1] >= 3:
        work01 = work01[..., :3]

    return work01, meta


def _hwc_rgb_float01_to_layout(img01, meta, *, scaled=True):
    """Convert HWC RGB float 0..1 data back to the original Siril layout.

    scaled=True  — preserve the original dtype/range (default, used for FITS/TIFF)
    scaled=False — return float32 normalized 0..1 in the original layout
                   (used for 8-bit JPEG write-back to avoid uint8 black-image bug)
    """
    img01 = np.clip(img01, 0.0, 1.0).astype(np.float32, copy=False)

    # If the source was mono, convert the signed RGB result back to luminance
    if meta["channels"] == 1:
        out_hwc = (0.2126 * img01[..., 0] +
                   0.7152 * img01[..., 1] +
                   0.0722 * img01[..., 2])[..., None].astype(np.float32, copy=False)
    else:
        out_hwc = img01

    if scaled:
        out = out_hwc * float(meta.get("output_scale", meta["scale"]))
        if meta["float_input"]:
            out = out.astype(meta["dtype"], copy=False)
        else:
            info = np.iinfo(meta["dtype"])
            out = np.rint(out)
            out = np.clip(out, info.min, info.max).astype(meta["dtype"])
    else:
        out = out_hwc.astype(np.float32, copy=False)

    if meta["layout"] == "HW":
        return out[..., 0]
    if meta["layout"] == "CHW":
        return np.transpose(out, (2, 0, 1))
    if meta["layout"] == "HWC":
        return out

    raise ValueError(f"Unsupported original layout: {meta['layout']}")


def _hwc_rgb_float01_to_original_layout(img01, meta):
    """Convert HWC RGB float 0..1 data back to original Siril layout/range/dtype."""
    return _hwc_rgb_float01_to_layout(img01, meta, scaled=True)


def apply_signature(siril, line1, line2, opacity_pct, flipped=True, position="Bottom Right", font_path=None, size1=28, size2=22, margin_pct=2.5):
    print(f"Applying signature — opacity {opacity_pct}% — margin {margin_pct}% — position: {position} — font: {os.path.basename(font_path) if font_path else 'default'} — sizes: {size1}/{size2}")

    try:
        with siril.image_lock():
            fit = siril.get_image(True)
            if fit is None:
                print("ERROR: No image loaded in Siril.")
                return False

            img_hwc, meta = _data_to_hwc_rgb_float01(fit.data)
            print(f"  Image shape from Siril: {meta['shape']}; dtype: {meta['dtype']}; detected scale: {meta['scale']}")

            height, width = img_hwc.shape[:2]

            pil_size = (width, height)

            # Font loading
            font1 = find_font(size1, font_path)
            font2 = find_font(size2, font_path)

            # Measure text
            dummy_draw = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
            bb1 = dummy_draw.textbbox((0, 0), line1, font=font1)
            bb2 = dummy_draw.textbbox((0, 0), line2, font=font2)
            tw1, th1 = bb1[2] - bb1[0], bb1[3] - bb1[1]
            tw2, th2 = bb2[2] - bb2[0], bb2[3] - bb2[1]
            gap = max(6, int(height * 0.005))

            print(f"  Flip correction: {flipped}")

            pos = position.lower()
            # Edge margin (1.4.0): user-set %, default 2.5. Dividing first keeps
            # the 2.5 default bit-identical to the old hard-coded 0.025 factor.
            margin_frac = float(margin_pct) / 100.0
            mx = int(width  * margin_frac)
            my = int(height * margin_frac)
            block_h = th1 + gap + th2

            # Horizontal alignment
            if "left" in pos:
                if flipped:
                    x1 = mx
                    x2 = mx
                else:
                    x1 = width - mx - tw1
                    x2 = width - mx - tw2
            elif "right" in pos:
                if flipped:
                    x1 = width - mx - tw1
                    x2 = width - mx - tw2
                else:
                    x1 = mx
                    x2 = mx
            else:  # center
                x1 = (width - tw1) // 2
                x2 = (width - tw2) // 2

            # Vertical alignment
            if "top" in pos:
                y1 = my
                y2 = y1 + th1 + gap
            elif "bottom" in pos:
                y1 = height - my - block_h
                y2 = y1 + th1 + gap
            else:  # middle / center
                y1 = (height - block_h) // 2
                y2 = y1 + th1 + gap

            # Draw text on a transparent overlay
            overlay = Image.new("RGBA", pil_size, (0, 0, 0, 0))
            draw = ImageDraw.Draw(overlay)
            alpha = int(255 * opacity_pct / 100.0)
            shadow_alpha = max(20, int(alpha * 0.35))

            draw.text((x1 + 1, y1 + 1), line1, font=font1, fill=(0, 0, 0, shadow_alpha))
            draw.text((x2 + 1, y2 + 1), line2, font=font2, fill=(0, 0, 0, shadow_alpha))
            draw.text((x1, y1), line1, font=font1, fill=(255, 255, 255, alpha))
            draw.text((x2, y2), line2, font=font2, fill=(255, 255, 255, alpha))

            if flipped:
                print("  Plate-solve flip detected — correcting text orientation.")
                overlay = overlay.transpose(Image.FLIP_TOP_BOTTOM)
            # Note: no horizontal flip applied when flipped=False.
            # The overlay is drawn directly without mirroring for unflipped images.

            # Blend overlay into normalized float image
            overlay_np = np.asarray(overlay, dtype=np.float32) / 255.0
            overlay_rgb = overlay_np[..., :3]
            overlay_alpha = overlay_np[..., 3:4]
            result_hwc = img_hwc * (1.0 - overlay_alpha) + overlay_rgb * overlay_alpha

            # Restore original Siril layout, then write back.
            # JPEG/8-bit path: write normalized float32 to avoid black-image
            # artifacts that occur when uint8 data is written into a 16-bit container.
            if meta.get("looks_8bit"):
                print("  8-bit/JPEG-like image detected — writing normalized float pixel data for safe save.")
                result_data = _hwc_rgb_float01_to_layout(result_hwc, meta, scaled=False)
                if result_data.shape != fit.data.shape:
                    raise ValueError(f"Internal shape mismatch: result {result_data.shape}, original {fit.data.shape}")
                siril.set_image_pixeldata(result_data)
            else:
                # Standard path — FITS, 16-bit TIFF, float FITS
                result_data = _hwc_rgb_float01_to_original_layout(result_hwc, meta)
                if result_data.shape != fit.data.shape:
                    raise ValueError(f"Internal shape mismatch: result {result_data.shape}, original {fit.data.shape}")
                fit.data[:] = result_data
                siril.set_image_pixeldata(fit.data)

            print("Signature applied successfully.")
            print(f"  Line 1 : {line1}")
            print(f"  Line 2 : {line2}")
            return True

    except Exception as e:
        print(f"ERROR applying signature: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    print("=" * 55)
    print(f"  AstroSignature Tool v{VERSION} — Randy Holder")
    print("  Two-line text signature for Siril 1.4+")
    print("=" * 55)

    params = get_user_input()
    if params is None:
        print("Cancelled.")
        return

    siril = s.SirilInterface()
    try:
        siril.connect()
        print("Connected to Siril.")
        success = apply_signature(siril, params["name"],
                                  params["session"], params["opacity"],
                                  params["flipped"], params["position"],
                                  params["font_path"], params["size1"],
                                  params["size2"],
                                  params.get("margin", DEFAULTS["margin"]))
        if success:
            print("")
            print("Done! Save as a new file to preserve your unsigned master.")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        siril.disconnect()


if __name__ == "__main__":
    main()
